﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MladiAstronomiApp
{
    public partial class Form1 : Form
    {
        private string filePath;
        Form2 Form2 = new Form2();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Čitanje datoteke 
            using (StreamReader sr = new StreamReader(@filePath))
            {
                //string za čitanje
                String line;

                List<Zvijezde_short> stars = new List<Zvijezde_short>();
                //var context = entity baze podataka
                Podaci_O_ZvijezdamaEntities ZvijezdeBaza = new Podaci_O_ZvijezdamaEntities();

                //Za standard insert instanca objekta, za bulkinsert polje objekata Zvijezde_short
                //Zvijezde_short Zvijezda = new Zvijezde_short();


                decimal distance;
                decimal magnitude;
                string proper;

                //Preskakanje prve linije
                string headerline = sr.ReadLine();

                while ((line = sr.ReadLine()) != null)
                {
                    //Polje stringova i rastavlja string na više dijelova
                    string[] parts = line.Split(',');
                    try
                    {
                        //ako je polje dulje od 0 charova onda izvlači proper, dist i mag
                        if (parts.Length != 0)
                        {
                            //Izvlačenje određeni string is polja
                            proper = parts[6];
                            //Parsanje decimalnog broja iz stringa
                            bool dist = decimal.TryParse(parts[9], out distance);
                            bool mag = decimal.TryParse(parts[13], out magnitude);
                            
                            stars.Add(new Zvijezde_short { Common_Name = proper, Distance = distance, Magnitude = magnitude });
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Exception caught!");
                    }
                }
                try
                {
                    //Standard insert za manju količinu podataka
                    //context.Zvijezde_short.Add(new Zvijezde_short { Common_Name = proper, Distance = distance, Magnitude = magnitude });
                    //context.SaveChanges();

                    //bulk insert za veću količinu podataka
                    ZvijezdeBaza.BulkInsert<Zvijezde_short>(stars);

                }
                catch (Exception)
                {
                    MessageBox.Show("Alert! Exception caught!");
                }


            }
        }

        //Button za importanje filea
        private void button2_Click(object sender, EventArgs e)
        {
            openFile = new OpenFileDialog();
            openFile.ShowDialog();

            //Uzimanje file patha i ubacivanje u streamreader konstruktor
            filePath = openFile.FileName;
            string fileName = openFile.SafeFileName;
            string path = filePath.Replace(fileName, "");


            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'podaci_O_ZvijezdamaDataSet.Zvijezde_short' table. You can move, or remove it, as needed.
            this.zvijezde_shortTableAdapter.Fill(this.podaci_O_ZvijezdamaDataSet.Zvijezde_short);
            FillDataGrid();
        }

        private void btn_Draw_Click(object sender, EventArgs e)
        {
            Form2.Show();
        }

        private void FillDataGrid()
        {
                //stvaranje novog datatablea koji će u sebi sadržavati zvijezde koje imaju proper
                //Nastanak problema: ako u tablici nema ništa neće se ispisati
                DataTable data = new DataTable("Tablica");
                data = podaci_O_ZvijezdamaDataSet.Zvijezde_short.Select("[Common_Name] <> ''").CopyToDataTable();
                dataGridView1.DataSource = data;   
        }
    }
}

