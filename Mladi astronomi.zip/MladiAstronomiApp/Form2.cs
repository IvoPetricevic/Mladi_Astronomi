﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MladiAstronomiApp
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {

            float sunCenterX = 650f;
            float sunCenterY = 250f;

            using (Graphics g = e.Graphics)
            {

                GraphicsExtensions.DrawCircle(g, Pens.Orange, sunCenterX, sunCenterY, 26.8f);
                GraphicsExtensions.FillCircle(g, Brushes.Orange, 650, 250, 26.8f);
                g.DrawString("Sun", this.Font, Brushes.White, sunCenterX - 12, sunCenterY + 40);

                GraphicsExtensions.DrawCircle(g, Pens.Red, sunCenterX + 150, sunCenterY, 9.38f);
                GraphicsExtensions.FillCircle(g, Brushes.Red, sunCenterX + 150, 250, 9.38f);
                g.DrawString("Proxima centauri", this.Font, Brushes.White, (sunCenterX + 150) - 45, sunCenterY - 40);

                GraphicsExtensions.DrawCircle(g, Pens.Yellow, sunCenterX - 165, 250, 33.5f);
                GraphicsExtensions.FillCircle(g, Brushes.Yellow, sunCenterX - 165, 250, 33.5f);
                g.DrawString("Rigil kentaurus", this.Font, Brushes.White, (sunCenterX - 165) - 43, sunCenterY + 40);

                GraphicsExtensions.DrawCircle(g, Pens.Red, sunCenterX + 250, 250, 5.36f);
                GraphicsExtensions.FillCircle(g, Brushes.Red, sunCenterX + 250, 250, 5.36f);
                g.DrawString("Barnard's star", this.Font, Brushes.White, (sunCenterX + 250) - 40, sunCenterY - 40);

                GraphicsExtensions.DrawCircle(g, Pens.Red, sunCenterX - 300, 250, 12.33f);
                GraphicsExtensions.FillCircle(g, Brushes.Red, sunCenterX - 300, 250, 12.33f);
                g.DrawString("Lilande 21185", this.Font, Brushes.White, (sunCenterX - 300) - 35, sunCenterY - 40);

                GraphicsExtensions.DrawCircle(g, Pens.LightGray, sunCenterX + 350, 250, 53.6f);
                GraphicsExtensions.FillCircle(g, Brushes.LightGray, sunCenterX + 350, 250, 53.6f);
                g.DrawString("Sirius", this.Font, Brushes.White, (sunCenterX + 350) - 15, sunCenterY - 70);

                GraphicsExtensions.DrawCircle(g, Pens.Red, sunCenterX - 400, 250, 32.43f);
                GraphicsExtensions.FillCircle(g, Brushes.Red, sunCenterX - 400, 250, 32.43f);
                g.DrawString("Lacaille 9352", this.Font, Brushes.White, (sunCenterX - 400) - 35, sunCenterY - 50);

                GraphicsExtensions.DrawCircle(g, Pens.LightYellow, sunCenterX + 450, 250, 37.52f);
                GraphicsExtensions.FillCircle(g, Brushes.LightYellow, sunCenterX + 450, 250, 37.52f);
                g.DrawString("Procyon", this.Font, Brushes.White, (sunCenterX + 450) - 20, sunCenterY - 60);

                GraphicsExtensions.DrawCircle(g, Pens.Red, sunCenterX - 500, 250, 9.38f);
                GraphicsExtensions.FillCircle(g, Brushes.Red, sunCenterX - 500, 250, 9.38f);
                g.DrawString("Luyten's star", this.Font, Brushes.White, (sunCenterX - 500) - 35, sunCenterY - 40);

                GraphicsExtensions.DrawCircle(g, Pens.Red, sunCenterX + 550, 250, 8.04f);
                GraphicsExtensions.FillCircle(g, Brushes.Red, sunCenterX + 550, 250, 8.04f);
                g.DrawString("Kapteyn's star", this.Font, Brushes.White, (sunCenterX + 550) - 35, sunCenterY - 40);

            }
        }
    }
}
