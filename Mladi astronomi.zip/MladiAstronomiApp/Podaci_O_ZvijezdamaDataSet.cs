﻿namespace MladiAstronomiApp
{


    partial class Podaci_O_ZvijezdamaDataSet
    {
    }
}
