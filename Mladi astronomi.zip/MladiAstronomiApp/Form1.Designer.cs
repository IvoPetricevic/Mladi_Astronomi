﻿namespace MladiAstronomiApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.saveButton = new System.Windows.Forms.Button();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.importButton = new System.Windows.Forms.Button();
            this.zvijezdeshortBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.podaci_O_ZvijezdamaDataSet = new MladiAstronomiApp.Podaci_O_ZvijezdamaDataSet();
            this.btn_Draw = new System.Windows.Forms.Button();
            this.zvijezde_shortTableAdapter = new MladiAstronomiApp.Podaci_O_ZvijezdamaDataSetTableAdapters.Zvijezde_shortTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.podaciOZvijezdamaDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.zvijezdeshortBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.podaci_O_ZvijezdamaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.podaciOZvijezdamaDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Arial", 8.25F);
            this.saveButton.Location = new System.Drawing.Point(12, 12);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(158, 23);
            this.saveButton.TabIndex = 0;
            this.saveButton.Text = "Save to database";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFile
            // 
            this.openFile.FileName = "openFile";
            this.openFile.Filter = "Excel files |*.csv|Text files|*.txt";
            // 
            // importButton
            // 
            this.importButton.Font = new System.Drawing.Font("Arial", 8.25F);
            this.importButton.Location = new System.Drawing.Point(13, 42);
            this.importButton.Name = "importButton";
            this.importButton.Size = new System.Drawing.Size(157, 23);
            this.importButton.TabIndex = 1;
            this.importButton.Text = "Import .csv file";
            this.importButton.UseVisualStyleBackColor = true;
            this.importButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // zvijezdeshortBindingSource
            // 
            this.zvijezdeshortBindingSource.DataMember = "Zvijezde_short";
            this.zvijezdeshortBindingSource.DataSource = this.podaci_O_ZvijezdamaDataSet;
            // 
            // podaci_O_ZvijezdamaDataSet
            // 
            this.podaci_O_ZvijezdamaDataSet.DataSetName = "Podaci_O_ZvijezdamaDataSet";
            this.podaci_O_ZvijezdamaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_Draw
            // 
            this.btn_Draw.Location = new System.Drawing.Point(13, 71);
            this.btn_Draw.Name = "btn_Draw";
            this.btn_Draw.Size = new System.Drawing.Size(157, 23);
            this.btn_Draw.TabIndex = 3;
            this.btn_Draw.Text = "Draw ";
            this.btn_Draw.UseVisualStyleBackColor = true;
            this.btn_Draw.Click += new System.EventHandler(this.btn_Draw_Click);
            // 
            // zvijezde_shortTableAdapter
            // 
            this.zvijezde_shortTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(194, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(286, 364);
            this.dataGridView1.TabIndex = 5;
            // 
            // podaciOZvijezdamaDataSetBindingSource
            // 
            this.podaciOZvijezdamaDataSetBindingSource.DataSource = this.podaci_O_ZvijezdamaDataSet;
            this.podaciOZvijezdamaDataSetBindingSource.Position = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(106)))), ((int)(((byte)(166)))));
            this.ClientSize = new System.Drawing.Size(492, 388);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_Draw);
            this.Controls.Add(this.importButton);
            this.Controls.Add(this.saveButton);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.zvijezdeshortBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.podaci_O_ZvijezdamaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.podaciOZvijezdamaDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.OpenFileDialog openFile;
        private System.Windows.Forms.Button importButton;
        private System.Windows.Forms.Button btn_Draw;
        private Podaci_O_ZvijezdamaDataSet podaci_O_ZvijezdamaDataSet;
        private System.Windows.Forms.BindingSource zvijezdeshortBindingSource;
        private Podaci_O_ZvijezdamaDataSetTableAdapters.Zvijezde_shortTableAdapter zvijezde_shortTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource podaciOZvijezdamaDataSetBindingSource;
    }
}

